# Machine Learning Final Project

## Implementation and Performance Analysis of Linear Regression and Logistic Regression Models

This project implements Linear Regression and Logistic Regression models from scratch and compares their performance with Scikit-learn implementations.

## Pipeline

- Data preprocessing
- Missing value handling
- Categorical encoding
- Outlier removal
- Normalization
- PCA dimensionality reduction
- Model training and evaluation

## Models

### Linear Regression
Used for predicting Average Daily Rate (ADR).

Evaluation:
- RMSE
- MAE
- R² Score

### Logistic Regression
Used for hotel booking cancellation prediction.

Evaluation:
- Accuracy
- Precision
- Recall
- F1 Score

## Results

Experiments:
- Baseline
- Normalization
- Normalization + PCA

Normalization provided the best improvement for Logistic Regression, while PCA reduced the number of features with a slight performance decrease.

## Results Folder

Contains project visualization outputs.
